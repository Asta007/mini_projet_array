<?php
$error = " ici repose une eventuelle erreur";




?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <title>Home</title>
</head>
<body>
    <div id="content_home">
        <div id="barre_rouge">
            <div id="nav_link">
                <a class="survole" href="home.php"> Accueil</a>
                <a href="list.php"> Liste</a>
                <a href="recherche.php"> Recherche</a>
                <a href="ajout.php"> Ajout</a>
                <a href="modif.php"> Modification</a>
                <a href="supp.php"> Suppression</a>
            </div>
        </div>

        <div id="banner_after_barre">
        <img src="img/gamezone1.jpg" alt="gamezone1.jpg">
        </div>

        <p class="welcome"> Welcome !</p>
    </div>
</body>
</html>